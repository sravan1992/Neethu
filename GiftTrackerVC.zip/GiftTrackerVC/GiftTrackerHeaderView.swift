//
//  GiftTrackerHeaderView.swift
//  WSGC-Products
//
//  Created by Sravan Kumar K P S on 26/11/19.
//  Copyright © 2019 Sravan Kumar K P S. All rights reserved.
//

import UIKit

class GiftTrackerHeaderView: UITableViewHeaderFooterView {
    
    static let headerIdentifier = "GiftTrackerHeaderView"
    @IBOutlet weak var bg_headerView:UIView!
    @IBOutlet weak var titleLabel:UILabel!
    @IBOutlet weak var sel_btn:UIButton!

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
