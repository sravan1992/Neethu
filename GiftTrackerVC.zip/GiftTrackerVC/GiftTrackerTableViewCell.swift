//
//  GiftTrackerTableViewCell.swift
//  WSGC-Products
//
//  Created by Sravan Kumar K P S on 26/11/19.
//  Copyright © 2019 Sravan Kumar K P S. All rights reserved.
//

import UIKit

class GiftTrackerTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
