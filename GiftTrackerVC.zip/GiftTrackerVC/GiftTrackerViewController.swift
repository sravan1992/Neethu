//
//  GiftTrackerViewController.swift
//  WSGC-Products
//
//  Created by Sravan Kumar K P S on 26/11/19.
//  Copyright © 2019 Sravan Kumar K P S. All rights reserved.
//

import UIKit


class GiftTrackerViewController: UIViewController {
    @IBOutlet weak var tblProducts: UITableView!
    
    let headerHeight:CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 60.0 : 60.0
    
    var selectedSections_array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addFewIntializers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNeedsStatusBarAppearanceUpdate()
    }
    
    //  MARK: - Status bar customization
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .darkContent
    }
    
    
    // MARK: - User defined Methods
    
    func addFewIntializers() {
                
        tblProducts.estimatedRowHeight = 44.0
        tblProducts.rowHeight = UITableView.automaticDimension
        
        let separatorInset = ((0.2 * view.frame.size.width) + 20)
        tblProducts.separatorInset = UIEdgeInsets(top: 0, left: separatorInset, bottom: 0, right: 0)
        
        let simpleHeaderNib = UINib.init(nibName: "GiftTrackerHeaderView", bundle: nil)
        tblProducts.register(simpleHeaderNib, forHeaderFooterViewReuseIdentifier: GiftTrackerHeaderView.headerIdentifier)
        tblProducts.tableFooterView = UIView(frame: CGRect.zero)
    }
    
    //MARK: - IBAction Methods
    
    @IBAction func sortButton_Action(_ sender: Any) {
    }
    
    
}


extension GiftTrackerViewController:UITableViewDelegate,UITableViewDataSource {
    
    // MARK: - UITableView Methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if selectedSections_array.contains(section) {
            return 2
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GiftTrackerTableViewCell") as? GiftTrackerTableViewCell else {
            return UITableViewCell()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return headerHeight
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: GiftTrackerHeaderView.headerIdentifier) as? GiftTrackerHeaderView else {
            return UIView()
        }
        
        // Change the arrow image here
        
        if selectedSections_array.contains(section) {
            // Expanded means down arrow
        } else {
            // Up arrow
        }
        
        
        headerView.sel_btn.tag = section
        headerView.sel_btn.addTarget(self, action: #selector(handleExpandOrClose(_:)), for: .touchUpInside)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    // MARK: TableView Added Methods
    @objc func handleExpandOrClose(_ button:UIButton) {
        let section = button.tag
        
        if let existedValueIndex = selectedSections_array.firstIndex(of: section) {
            selectedSections_array.remove(at: existedValueIndex)
        } else {
            selectedSections_array.append(section)
        }
        
        tblProducts.reloadSections(IndexSet(integer: section), with: .automatic)
    }
    
}

